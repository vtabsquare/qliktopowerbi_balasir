# Enterprise Complex QlikView migration test package

This package is designed to test the QVW/PRJ analysis pages of the Qlik-to-Power BI migration application.

## Included

- `EnterpriseComplexDashboard.qvw`: a synthetic non-openable QVW placeholder used only to test QVW inventory and package classification.
- `EnterpriseComplexDashboard-prj/`: a comprehensive QlikView project-definition folder containing document, sheet, object, expression, variable, parameter, bookmark, action, trigger, macro, extension and layout metadata.
- Existing QVS scripts, source CSV files, extension definitions and application metadata from the original test package.
- `source-connections.csv`: source mapping information for full-migration readiness testing.

## Important limitation

A genuine `.qvw` is a proprietary QlikView binary that must be created by QlikView Desktop on Windows. The placeholder in this ZIP cannot be opened in QlikView Desktop. The migration application should analyze the supplied `-prj` XML/TXT files; these files contain the complete synthetic test metadata.

## Expected parser coverage

- 8 sheets
- 50 original visualization/filter/container objects
- 14 supplemental interaction and parameter objects
- 15 variables
- 5 document bookmarks
- Multiple Set Analysis, Aggr/inter-record, conditional-formatting and variable-driven expressions
- Navigation, bookmark, selection, clear, variable, URL, macro and export-style actions
- Document, sheet, object, field and variable triggers
- 3 macros
- 3 custom extensions
- Alternate states, drill-down groups and a cyclic group

Generated: 2026-07-16T09:25:51.654206+00:00
