define([], function () {
  return {
    definition: {},
    initialProperties: {
      qHyperCubeDef: {
        qDimensions: [],
        qMeasures: [],
        qInitialDataFetch: [{ qWidth: 5, qHeight: 100 }]
      }
    },
    paint: function ($element) {
      $element.html("<div>com-margin-waterfall</div>");
    }
  };
});
